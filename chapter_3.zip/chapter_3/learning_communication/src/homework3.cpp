#include "ros/ros.h"
#include "learning_communication/PersonSrv.h"
#include <geometry_msgs/Twist.h>
#include "turtlesim/Spawn.h"
#include "time.h"
#include "string"

// 使用ros::Publisher这个类实例化turtle_vel_pub对象
ros::Publisher turtle_vel_pub;
// 使用ros::ServiceServer这个类实例化command_service对象
ros::ServiceServer command_service;

//定义线速度v，角速度w和乌龟停止或者前进的状态state三个全局变量
int v,w,state;
//定义被控制的海龟名字turtle_controlled和新生成的海龟名字turtle_new两个字符类型的全局变量
std::string turtle_controlled;
std::string turtle_new;

// service回调函数，输入参数req，输出参数res
bool commandCallback(learning_communication::PersonSrv::Request  &req,
         	     learning_communication::PersonSrv::Response &res)
{
	// 显示请求数据
    	ROS_INFO("the name of new turtle: %s  the name of turtle controlled: %s  state(0 is running, other is stop): %d  linear velocity: %d  angular velocity: %d", req.turtle_new.c_str(), req.turtle_controlled.c_str(), req.state, req.v, req.w);
	//将命令行输入的乌龟停止或者前进的状态，线速度，角速度，被控制的海龟名字和新生成的海龟名字分别赋值给全局变量
	state = req.state;   
	v = req.v;
	w = req.w;
        turtle_controlled = req.turtle_controlled;
	turtle_new = req.turtle_new;

	// 创建节点句柄
 	ros::NodeHandle n;
	// 等待/spawn服务
	ros::service::waitForService("/spawn");
        // 使用ros::ServiceClient类实例化client对象，创建客户端client，数据类型为turtlesim::Spawn，服务名字为/spawn
	ros::ServiceClient client = n.serviceClient<turtlesim::Spawn>("/spawn");

        // 创建turtlesim::Spawn类型的数据new_turtle
	turtlesim::Spawn new_turtle;
	// 生成随机数种子
	srand(time(NULL));
	// 定义新海龟初始位置横纵坐标，随机出现
	new_turtle.request.x = random()%10;
	new_turtle.request.y = random()%10;
	// 定义新海龟名字
	new_turtle.request.name = turtle_new;
        // 客户端请求服务调用
	client.call(new_turtle);
	// 发布者发布geometry_msgs::Twist消息类型的话题，话题名字为turtle_controlled + "/cmd_vel"，队列长度10
	turtle_vel_pub = n.advertise<geometry_msgs::Twist>(turtle_controlled + "/cmd_vel", 10);

  	// 设置反馈数据
	res.message = "OK";
        return true;
}

int main(int argc, char **argv)
{
        // ROS节点初始化
        ros::init(argc, argv, "homework3");
        // 创建节点句柄
        ros::NodeHandle n;
        // 创建一个名为/turtle_command的server，注册回调函数commandCallback
        command_service = n.advertiseService("/turtle_command", commandCallback);
	//周期发布速度指令
	ros::Rate loop_rate(10);
	//当节点运行时
	while(ros::ok())
	{
		// 调用回调函数同时继续周期发布速度指令
		ros::spinOnce();
		// state>0认为前进，state=0认为停止
		if(state>0)
		{
			// 创建消息类型为geometry_msgs::Twist的消息vel_msg
			geometry_msgs::Twist vel_msg;
			// 将线速度全局变量赋值给海龟
			vel_msg.linear.x = v;
			// 将角速度全局变量赋值给海龟
			vel_msg.angular.z = w;
			// 发布者发布速度消息
			turtle_vel_pub.publish(vel_msg);
			//周期发布速度指令
			loop_rate.sleep();
		}
	}
    return 0;
}
