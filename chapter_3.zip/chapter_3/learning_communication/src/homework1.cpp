#include <ros/ros.h>
#include <geometry_msgs/Twist.h>   //描述发布海龟速度指令的消息结构的头文件
#include "turtlesim/Pose.h"        //描述海龟位置的消息结构的头文件

//创建消息类型为urtlesim::Pose的常数指针position
void circle_callback(const turtlesim::Pose::ConstPtr& position)  
{
	//终端显示海龟实时位置的信息
	ROS_INFO("the position of this turtle is: x:%0.4f, y:%0.4f", position->x, position->y);
}

int main(int argc, char **argv)
{
	// ROS节点初始化
	ros::init(argc, argv, "homework1");

	// 创建节点句柄
	ros::NodeHandle n;

	// 使用ros::Publisher这个类实例化circle_pub对象，从而创建发布者circle_pub，订阅/turtle1/cmd_vel这个话题，消息类型为geometry_msgs::Twist，队列长度为10
	ros::Publisher circle_pub = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 10);

        // 使用ros::Subscriber这个类实例化circle_sub对象，从而创建订阅者circle_sub，订阅/turtle1/pose这个话题，队列长度为10，注册回调函数circle_callback
        ros::Subscriber circle_sub = n.subscribe("/turtle1/pose", 10, circle_callback);

	//周期发布速度指令
	ros::Rate loop_rate(10);

	while (ros::ok())
	{
		// 创建消息类型为geometry_msgs::Twist的消息speed
		geometry_msgs::Twist speed;

		// 设定线速度为0.4m/s
		speed.linear.x = 0.4;

		// 设定角速度为0.6rad/s
		speed.angular.z = 0.6;
		
		// 发布者发布速度消息
		circle_pub.publish(speed);

		//ROS_INFO("the speed of this turtle is:[%0.2f m/s, %0.2f rad/s]", speed.linear.x, speed.angular.z);

	    	// 调用回调函数同时继续周期发布速度指令
           	ros::spinOnce(); 

		//周期发布速度指令
	        loop_rate.sleep();
	}
      
	return 0;
}


