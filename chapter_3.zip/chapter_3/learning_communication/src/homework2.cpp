#include <ros/ros.h>
#include <turtlesim/Spawn.h>

int main(int argc, char** argv)
{
        // 初始化ROS节点
	ros::init(argc, argv, "homework2");

        // 创建节点句柄
	ros::NodeHandle node;

        //  等待spawn服务
	ros::service::waitForService("/spawn");
        // 使用ros::ServiceClient类实例化client对象，创建客户端client，数据类型为turtlesim::Spawn，服务名字为/spawn
	ros::ServiceClient client = node.serviceClient<turtlesim::Spawn>("/spawn");

        // 创建turtlesim::Spawn类型的数据second
	turtlesim::Spawn second;

        // 定义新海龟初始位置横纵坐标
	second.request.x = 4.0;
	second.request.y = 7.0;

	// 定义新海龟名字
	second.request.name = "turtle2";

        // 客户端请求服务调用
	client.call(second);

	// 终端打印客户端请求的新海龟坐标和名字
	ROS_INFO("Call service to spwan turtle[x:%0.6f, y:%0.6f, name:%s]", 
			 second.request.x, second.request.y, second.request.name.c_str());
	// 终端打印服务器响应新海龟名字
	ROS_INFO("Spwan turtle successfully [name:%s]", second.response.name.c_str());

	return 0;
};
